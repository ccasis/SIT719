About us
========


Core Development Team
---------------------

Yue Zhao (Ph.D. Student @ Carnegie Mellon University; MSc in Computer Science from University of Toronto):

- Initialized the project in 2017
- `Homepage <https://www.andrew.cmu.edu/user/yuezhao2/>`_
- `LinkedIn (Yue Zhao) <https://www.linkedin.com/in/yzhao062/>`_

Zain Nasrullah (Data Scientist at RBC; MSc in Computer Science from University of Toronto):

- Joined in 2018
- `LinkedIn (Zain Nasrullah) <https://www.linkedin.com/in/zain-nasrullah-097a2b85>`_

Winston (Zheng) Li (Founder of `arima <https://www.arimadata.com/>`_, Stat Ph.D. from University of Toronto, Instructor @ Northeastern University):

- Joined in 2018
- `LinkedIn (Winston Li) <https://www.linkedin.com/in/winstonl>`_

Yahya Almardeny (Software Systems & Machine Learning Engineer @ TSSG):

- Joined in 2019
- `LinkedIn (Yahya Almardeny) <https://www.linkedin.com/in/yahya-almardeny/>`_

